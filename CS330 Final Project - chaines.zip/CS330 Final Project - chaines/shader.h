#pragma once

#include <GL/glew.h>        // GLEW library
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <string>
#include <fstream>
#include <sstream>
#include <iostream>

/**
 * @brief Encapsulates shader program
 * @details Reads vertex and fragment shaders from file and attaches them to a shader program
 * that can be used for rendering in OpenGL
*/
class Shader {
public:
	// the program ID
	/**
	* @brief Shader program ID
	*/
	unsigned int ID;

	/**
	 * @brief Construct a Shader object
	 * @param vertexPath Path to vertex shader source file on disk
	 * @param fragmentPath Path to fragment shader source file on disk
	*/
	Shader(const char* vertexPath, const char* fragmentPath);

	/**
	* @brief Destroys shader program
	*/
	~Shader();
	
	// use/activate the shader
	/**
	* @brief Activates shader program for OpenGL rendering
	*/
	void use();

	// utility uniform functions
	/**
	* @brief Set bool uniform
	* @param name Name of uniform
	* @param value Uniform bool value
	*/
	void setBool(const std::string& name, bool value) const;

	/**
	 * @brief Set integer uniform
	 * @param name Uniform name
	 * @param value Uniform integer value
	*/
	void setInt(const std::string& name, GLint value) const;

	/**
	 * @brief Set float uniform
	 * @param name  Uniform name
	 * @param value Uniform float value
	*/
	void setFloat(const std::string& name, GLfloat value) const;

	/**
	 * @brief Set glm::vec4 uniform
	 * @param name Uniform name
	 * @param value Uniform glm::vec4 value
	*/
	void setVec4(const std::string& name, glm::vec4 value);

	/**
	 * @brief Set glm::mat4 uniform
	 * @param name Uniform name
	 * @param value Uniform glm::mat4 value
	*/
	void setMat4(const std::string &name, glm::mat4 value);

	void setVec3(const std::string &name, glm::vec3 value);

	void setVec3(const std::string& name, float x, float y, float z);

	void setVec2(const std::string& name, glm::vec2 value);

	void setVec2(const std::string& name, float x, float y);
	
};



