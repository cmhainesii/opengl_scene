#include "mesh.h"
#include <array>

constexpr GLuint PLANE_VERTEX_ARRAY_SIZE { 8 * 6 };



class Plane
{

 public:
    Plane();
    Plane(std::array<GLfloat, PLANE_VERTEX_ARRAY_SIZE> vertexArray, GLuint texture);
    
    void draw();

 private:
    GLuint texture;
    GLMesh mesh;
};