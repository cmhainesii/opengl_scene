/**
 * @file mesh.h
 * @author Charles Haines <charles.haines@snhu.edu>
 * @brief Defines GLMesh struture for storing mesh data
 * @date 2022-04-10
 * 
 * CS330 Southern New Hampshire University
 * 
 */

    #ifndef __MESH_H__
    #define __MESH_H__

    #include <GL/glew.h>

    struct GLMesh
    {
        GLuint vao;         // Handle for the vertex array object
        GLuint vbo, vbo2;     // Handles for the vertex buffer objects
        GLuint nIndices;    // Number of indices of the mesh
        
    };

    #endif