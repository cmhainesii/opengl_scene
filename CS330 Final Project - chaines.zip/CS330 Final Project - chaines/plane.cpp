#include "plane.h"

Plane::Plane() {}

Plane::Plane(std::array<GLfloat, PLANE_VERTEX_ARRAY_SIZE> vertexArray, GLuint texture)
{
    // Generate and activate VAOs and VBOs. Send vertex data to GPU.
    glGenVertexArrays(1, &mesh.vao);
    glGenBuffers(1, &mesh.vbo);
    glBindVertexArray(mesh.vao);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo);
    glBufferData(GL_ARRAY_BUFFER, vertexArray.size() * sizeof(vertexArray.at(0)), &vertexArray.front(), GL_STATIC_DRAW);

    // Calculate stride and set vertex attribute pointers
    const int FLOATS_PER_VERTEX{ 3 };
    const int FLOATS_PER_TEX_COORD{ 2 };
    const int FLOATS_PER_NORMAL{ 3 };
    const unsigned stride{ (FLOATS_PER_VERTEX + FLOATS_PER_NORMAL + FLOATS_PER_TEX_COORD) * sizeof(float) };
    constexpr unsigned VERTEX_BYTE_SIZE = 9 * sizeof(float);

    // Pointers for vertices, normals, then texture coordinates.
    glVertexAttribPointer(0, FLOATS_PER_VERTEX, GL_FLOAT, GL_FALSE, stride, (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, FLOATS_PER_NORMAL, GL_FLOAT, GL_FALSE, stride, (void*)(FLOATS_PER_VERTEX * sizeof(float)));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, FLOATS_PER_TEX_COORD, GL_FLOAT, GL_FALSE, stride, (void*)((FLOATS_PER_VERTEX + FLOATS_PER_NORMAL) * sizeof(float)));
    glEnableVertexAttribArray(2);

    // Set texture field
    this->texture = texture;

}

void Plane::draw()
{
    glBindVertexArray(mesh.vao);
    glBindTexture(GL_TEXTURE_2D, texture);
    glDrawArrays(GL_TRIANGLES, 0, 6);
    glBindVertexArray(0);
}