/*
* Source.cpp
* 
* Application Main Entry Point
* 
* Uses modified version of camera.h from learnopengl.com
* 
* CS330 - Final Project
* Charles Haines 
* Southern New Hampshire University
* 03/25/2022 
* 
* In the final installment of this project, I have added all
* of the objects from my 2D picutre into my 3D OpenGL scene.
* I have added a Sphere class as well as a Cube and Plane class to
* support the creation of Sphere, Cube, and Plane objects.
*
* This project was tested on Arch Linux using gcc and Windows using Visual Studio 2022 (MSVC).
* 
* The following two flags are set to comply with the assignment requirements. Change these
* variables to increase the polygon count and set a larger window resolution. The flags
* are located in the unnamed namespace containing golbal variables.

* LOW_POLYGON_COUT_MODE is enabled by default and limits the polygon count
* for all objects to <= 1000 polygons. Set LOW_POLOGON_COUNT_MODE to false
* for the best experience. Change this to make the sphere look more like a sphere.
*
* Set FULL_HD_SIZE to set the window resolution to 1920x1080. This is
* set to false by default and provides a default window resolution of 
* 800x600. 
*
* Also set renderLightSource to true to render cube objects depiciting 
* where the light sources are in the scene. This is set to false by default. 
*/


#include <iostream>         // cout, cerr
#include <vector>           // std::vector
#include <array>            // std::array
#include <memory>           // std::unique_ptr
#include <cstdlib>          // EXIT_FAILURE
#include <GL/glew.h>        // GLEW library
#include <GLFW/glfw3.h>     // GLFW library

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

// Camera Class from learnOpenGL.com
#include "camera.h"
#include "shader.h"
#include "cylinder.h"

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#include "Sphere.h"
#include "mesh.h"
#include "cube.h"
#include "plane.h"

// Keep code shorter & easier to read
using static_meshes_3D::Cylinder;



// Custom deleter for window pointer
struct glDeleter {
    void operator()(GLFWwindow* wnd)
    {
        std::cout << "Destroying GLFW window context" << std::endl;
        glfwDestroyWindow(wnd);
    }
};

// Materials Enum - Used by function that can set various lighting/material
// properties for a given material.
enum class Materials {
    METALLIC,
    GENERIC
};



// Unnamed namespace
namespace
{
    // Limits objects to a maximum of 1000 polygons if true
    constexpr bool LOW_POLYGON_COUNT_MODE = true;

    // Window resolution 1920x1080 if true, 800x600 if false.
    constexpr bool FULL_HD_SIZE = false;

    const std::string WINDOW_TITLE = "CS330 Final Project - Charles Haines - SNHU 2022"; // Macro for window title
    
    // Values to be set by main()
    unsigned WINDOW_WIDTH, WINDOW_HEIGHT;
    

    // If true, the light source will render as a small cube.
    // in the current scene, it is hidden under the plane
    // since light is traveling toward the light source
    const bool renderLightSource = false;

    constexpr int CUBE_VERTICES_COUNT = 8 * 6 * 6; //vertices per line, number of lines per cube face, number of faces
    constexpr size_t NUM_POINT_LIGHTS = 4; 
    constexpr unsigned int NUMBER_OF_MESHES = 3;

    // Main GLFW window
    //GLFWwindow* gWindow = nullptr;
    std::unique_ptr<GLFWwindow, glDeleter> gWindow;
    
    // Array of meshes for the scene
    
    std::array<GLMesh, NUMBER_OF_MESHES> gMeshes;
    
    // Shader programs
    std::unique_ptr<Shader> objectShader;
    std::unique_ptr<Shader> lightSourceShader;

    // Declare pinball sphere object
    Sphere sphere;

    // Declare pointers to cylinder objects
    std::unique_ptr<Cylinder> bottomCylinder  = nullptr;
    std::unique_ptr<Cylinder> topCylinder     = nullptr;
    std::unique_ptr<Cylinder> middleCylinder  = nullptr;
    std::unique_ptr<Cylinder> coffeeCup       = nullptr;
    std::unique_ptr<Cylinder> coffeeCupHandle = nullptr;


    // Boolean to track first frame
    bool first = true;    

    // Declare cube objects for battery and lamp cubes
    Cube batteryObject;
    Cube dirLightCube;
    
    // Variables for light properties
    std::array<Cube, NUM_POINT_LIGHTS> pointLightCubes;
    std::array<glm::vec3, NUM_POINT_LIGHTS> pointLightPositions;
    glm::vec3 lightDir(-0.3f, -1.0f, -0.3f);

    // Plane object to represent table
    Plane table;


    // Camera Setup
    Camera gCamera(glm::vec3(0.0f, 5.0f, 12.0f));
    float gLastX = WINDOW_WIDTH / 2.0f;
    float gLastY = WINDOW_HEIGHT / 2.0f;
    bool gFirstMouse = true;
    bool orthographicView = false;

    // Timing
    float gDeltaTime = 0.0f;
    float gLastFrame = 0.0f;

    // Textures
    const unsigned int NUMBER_OF_TEXTURES = 6;
    std::array<unsigned int, NUMBER_OF_TEXTURES> textures;   
}

/* User-defined Function prototypes to:
 * initialize the program, set the window size,
 * redraw graphics on the window when resized,
 * and render graphics on the screen
 */
bool UInitialize(int, char* [], GLFWwindow** window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
void UCreateMesh(std::array<GLMesh, NUMBER_OF_MESHES> &meshes, std::array<unsigned int, NUMBER_OF_TEXTURES> &textures);
void UDestroyMesh(std::array<GLMesh, NUMBER_OF_MESHES> meshes);
void URender();
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos);
void UScrollCallback(GLFWwindow* window, double xoffsetIn, double yoffsetIn);
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods);
void USetDefaultTextureParameters();
bool UCreateTexture(const char* filename, GLuint& textureId);
void flipImageVertically(unsigned char* image, int width, int height, int channels);
void setMaterialProperties(Shader* shader, Materials material);
void UKeyCallback(GLFWwindow *window, int key, int scancode, int action, int mods);
void USetupUniforms();
// Application entry point - Set up window and enter main rendering loop
int main(int argc, char* argv[])
{

    // Set screen size at either 1920x1080 or 800x600
    if (FULL_HD_SIZE)
    {
        WINDOW_WIDTH = 1920;
        WINDOW_HEIGHT = 1080;
    }
    else
    {
        WINDOW_WIDTH = 800;
        WINDOW_HEIGHT = 600;   
    }

    // Pointer to window object
    GLFWwindow* window = nullptr;

    // Start initiliziation
    if (!UInitialize(argc, argv, &window))
        return EXIT_FAILURE;

    // Transfer pointer ownership for *window to global unique_ptr
    gWindow.reset(window);

    // Create the shader program
    objectShader.reset(new Shader("shader.vs", "shader.frs"));
    if (renderLightSource)
    {
        lightSourceShader.reset(new Shader("cubeShader.vs", "cubeShader.frs"));
    }
    
    // Create the mesh
    UCreateMesh(gMeshes, textures); // Calls the function to create the Vertex Buffer Object

    // render loop
    // -----------

    while (!glfwWindowShouldClose(gWindow.get()))
    {
        // Timing
        float currentFrame = glfwGetTime();
        gDeltaTime = currentFrame - gLastFrame;
        gLastFrame = currentFrame;

        // input
        // -----
        UProcessInput(gWindow.get());

        // Render this frame
        URender();

        glfwPollEvents();
    }

    // Release mesh data
    UDestroyMesh(gMeshes);

    exit(EXIT_SUCCESS); // Terminates the program successfully
}


// Initialize GLFW, GLEW, and create a window
bool UInitialize(int argc, char* argv[], GLFWwindow** window)
{
    // GLFW: initialize and configure
    // ------------------------------
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    // GLFW: window creation
    // ---------------------
    * window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE.c_str(), NULL, NULL);
    if (*window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return false;
    }
    glfwMakeContextCurrent(*window);
    glfwSetFramebufferSizeCallback(*window, UResizeWindow);
    glfwSetCursorPosCallback(*window, UMousePositionCallback);
    glfwSetScrollCallback(*window, UScrollCallback);
    glfwSetMouseButtonCallback(*window, UMouseButtonCallback);
    glfwSetKeyCallback(*window, UKeyCallback);

    // Capture mouse so it is not displayed when window is active
    glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // GLEW: initialize
    // ----------------
    // Note: if using GLEW version 1.13 or earlier
    glewExperimental = GL_TRUE;
    GLenum GlewInitResult = glewInit();

    if (GLEW_OK != GlewInitResult)
    {
        std::cerr << glewGetErrorString(GlewInitResult) << std::endl;
        return false;
    }

    // Displays GPU OpenGL version
    std::cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << std::endl;

    return true;
}


// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
void UProcessInput(GLFWwindow* window)
{
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    // Handle keyboard events for WASD (left, right, forward, and backward movement)
    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        gCamera.ProcessKeyboard(FORWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        gCamera.ProcessKeyboard(BACKWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        gCamera.ProcessKeyboard(LEFT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        gCamera.ProcessKeyboard(RIGHT, gDeltaTime);

    // Handle Q & E keyboard input to move the camera down and up.
    // Added UP and DOWN directions to the camera.h class to make this work
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        gCamera.ProcessKeyboard(UP, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        gCamera.ProcessKeyboard(DOWN, gDeltaTime);
}


// glfw: whenever the window size changed (by OS or user resize) this callback function executes
void UResizeWindow(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}


// Functioned called to render a frame
void URender()
{
    // Enable z-depth
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_NORMALIZE);

    // Clear the frame and z buffers
    glClearColor(0.2f, 0.3f, 0.3f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Activate Brick Texture!
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, textures.at(0));
    
    
    // Enable object shader
    objectShader->use();

    
    //Set lighting and texture properties
    // and send the to the GPU
    USetupUniforms();

    // Create either projection or orthographic view
    glm::mat4 projection;

    if (!orthographicView)
    {
        projection = glm::perspective(gCamera.Zoom, (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }
    else
    {
        projection = glm::ortho(-10.0f, 10.0f, -10.0f, 10.0f, 0.1f, 100.0f);
    }
    
    objectShader->setMat4("projection", projection);
    

    // Camera / View Transform
    glm::mat4 view = gCamera.GetViewMatrix();
    objectShader->setMat4("view", view);
    
    
    // Create, transform, and scale model matrix
    // and send to GPU
    glm::mat4 model = glm::mat4(1.0f);
    model = glm::translate(model, glm::vec3(0.0f, 0.0f, 0.0f));
    model = glm::scale(glm::vec3(2.0f, 2.0f, 2.0f));
    objectShader->setMat4("model", model);

    // Draw table object
    table.draw();
    
    
    // Set top/bottom cylinder texture and activate
    // bottom cylinder mesh
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, textures.at(1));
    
    // Position object in world with model
    // matrix and send to GPU.
    model = glm::mat4(1.0f);
    model = glm::translate(model, glm::vec3(4.5f, 0.251f, 0.0f));
    objectShader->setMat4("model", model);


    // Render bottom cylinder for E-Tank
    bottomCylinder->render();
    

    // Activate middle cylinder texture
    glBindTexture(GL_TEXTURE_2D, textures.at(2));

    // Position middle cylinder via model matrix
    // and send to GPU
    model = glm::mat4(1.0f);
    model = glm::translate(model, glm::vec3(4.5f, 1.75f, 0.0f));
    model = glm::rotate(model, glm::radians(-45.0f), glm::vec3(0.0f, 1.0f, 0.0f));
    objectShader->setMat4("model", model);

    // Render middle cylinder
    middleCylinder->render();    

    // Activate top cylinder texture
    glBindTexture(GL_TEXTURE_2D, textures.at(1));

    // Position top cylinder via model matrix
    // and send to GPU
    model = glm::mat4(1.0f);
    model = glm::translate(model, glm::vec3(4.5f, 3.25f, 0.0f));
    objectShader->setMat4("model", model);


    // Render top cylinder of E-Tank
    topCylinder->render();

    // Draw light source if renderLightSource is set to true
    if (renderLightSource)
    {
        // Send model, view, and projection matrice uniforms and render the lightSource as a 
        // small cube.
        model = glm::mat4(1.0f);
        model = glm::translate(model, lightDir);
        model = glm::scale(model, glm::vec3(0.2f));

        // Switch to light source shader and
        // set uniforms for model, view, and projection.
        lightSourceShader->use();
        lightSourceShader->setMat4("view", view);
        lightSourceShader->setMat4("projection", projection);
        lightSourceShader->setMat4("model", model);
        
        // Draw light source as a cube
        dirLightCube.draw();

        for (auto i = 0; i < NUM_POINT_LIGHTS; ++i)
        {
            model = glm::mat4(1.0f);
            model = glm::translate(model, pointLightPositions.at(i));
            model = glm::scale(model, glm::vec3(0.2f));
            lightSourceShader->setMat4("model", model);
            pointLightCubes.at(i).draw();
        }
    }

    // Switch back to objectShader    
    objectShader->use();


    // Draw Battery
    model = glm::mat4(1.0f);
    model = glm::translate(model, glm::vec3(-3.0f, 0.0f, 6.0f));
    model = glm::rotate(model, glm::radians(45.0f), glm::vec3(0.0f, 1.0f, 0.0f));
    model = glm::scale(model, glm::vec3(4.0f));
    objectShader->setMat4("model", model);
    batteryObject.draw();
    
    // Draw pinball
    glBindVertexArray(gMeshes.at(2).vao);
    glBindTexture(GL_TEXTURE_2D, textures.at(3));
    model = glm::mat4(1.0f);
    model = glm::translate(model, glm::vec3(1.5f, 0.996f, 5.0f));
    objectShader->setMat4("model", model);
    setMaterialProperties(objectShader.get(), Materials::METALLIC);

    sphere.draw();
    glBindVertexArray(0);

    // Render cylinder for coffee mug
    glBindTexture(GL_TEXTURE_2D, textures.at(5));
    model = glm::mat4(1.0f);
    model = glm::translate(model, glm::vec3(-3.0f, 1.505f, -1.0f));
    objectShader->setMat4("model", model);
    coffeeCup->render(false, true);



    // Render coffee mug handle
    glBindTexture(GL_TEXTURE_2D, textures.at(5));
    model = glm::mat4(1.0f);
    model = glm::translate(model, glm::vec3(-5.495f, 1.8f, -1.0f));
    model = glm::rotate(model, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
    objectShader->setMat4("model", model);
    coffeeCupHandle->render(false, false);

    
    // glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
    glfwSwapBuffers(gWindow.get());    // Flips the the back buffer with the front buffer every frame.
}

// Implements the UCreateMesh function
void UCreateMesh(std::array<GLMesh, NUMBER_OF_MESHES> &meshes, std::array<unsigned int, NUMBER_OF_TEXTURES> &textures)
{
    // Byte array to contain image
    unsigned char* data{ nullptr };

    // Initialize image dimension variables
    int width{}, height{}, nrChannels{};

    // Phase 1 -> Define vertex arrays for various object meshes
    constexpr unsigned PLANE_VERTEX_COUNT = 8 * 6; // floats per line * number of lines
    std::array<GLfloat, PLANE_VERTEX_COUNT> planeVertexArray = {

        // position         //normals         // texture coords
        -5.0f, 0.0f, -5.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f,
        5.0f,  0.0f, -5.0f, 0.0f, 1.0f, 0.0f, 1.0f, 0.0f,
        5.0f,  0.0f, 5.0f, 0.0f, 1.0f, 0.0f, 1.0f, 1.0f,
        5.0f,  0.0f, 5.0f, 0.0f, 1.0f, 0.0f, 1.0f, 1.0f,
        -5.0f, 0.0f, 5.0f, 0.0f, 1.0f, 0.0f, 0.0f, 1.0f,
        -5.0f, 0.0f, -5.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f
    };
    
    // Define vertices for cube objects
    std::array<GLfloat, CUBE_VERTICES_COUNT> cubeVertices = {
        // positions          // normals           // texture coords
        -0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,
        0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f,
        0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 1.0f,
        0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 1.0f,
        -0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f, 1.0f,
        -0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f,

        -0.5f, -0.5f,  0.5f,  0.0f,  0.0f, 1.0f,   0.0f, 0.0f,
        0.5f, -0.5f,  0.5f,  0.0f,  0.0f, 1.0f,   1.0f, 0.0f,
        0.5f,  0.5f,  0.5f,  0.0f,  0.0f, 1.0f,   1.0f, 1.0f,
        0.5f,  0.5f,  0.5f,  0.0f,  0.0f, 1.0f,   1.0f, 1.0f,
        -0.5f,  0.5f,  0.5f,  0.0f,  0.0f, 1.0f,   0.0f, 1.0f,
        -0.5f, -0.5f,  0.5f,  0.0f,  0.0f, 1.0f,   0.0f, 0.0f,

        -0.5f,  0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f, 0.0f,
        -0.5f,  0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  1.0f, 1.0f,
        -0.5f, -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
        -0.5f, -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
        -0.5f, -0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  0.0f, 0.0f,
        -0.5f,  0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f, 0.0f,

        0.5f,  0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f, 0.0f,
        0.5f,  0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  1.0f, 1.0f,
        0.5f, -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
        0.5f, -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
        0.5f, -0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  0.0f, 0.0f,
        0.5f,  0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f, 0.0f,

        -0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  0.0f, 1.0f,
        0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  1.0f, 1.0f,
        0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  1.0f, 0.0f,
        0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  1.0f, 0.0f,
        -0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  0.0f, 0.0f,
        -0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  0.0f, 1.0f,

        -0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  0.0f, 1.0f,
        0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  1.0f, 1.0f,
        0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  1.0f, 0.0f,
        0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  1.0f, 0.0f,
        -0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  0.0f, 0.0f,
        -0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  0.0f, 1.0f
    };

    // Battery vertices
    std::array<GLfloat, CUBE_VERTICES_COUNT> batteryVertices {
        // Front face
        -0.5f, 0.0f, 0.2f, 0.0f, 0.0f, 1.0f, 1.0f, 0.0f,
        -0.5f, 0.1f, 0.2f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f,
        0.5f,  0.1f, 0.2f, 0.0f, 0.0f, 1.0f, 0.0f, 1.0f,
        0.5f,  0.1f, 0.2f, 0.0f, 0.0f, 1.0f, 0.0f, 1.0f,
        0.5f,  0.0f, 0.2f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f,
        -0.5f, 0.0f, 0.2f, 0.0f, 0.0f, 1.0f, 1.0f, 0.0f,

        //Back face
         -0.5, 0.0f, 0.0f, 0.0f, 0.0f, -1.0f, 1.0f, 0.0f,
        -0.5f, 0.1f, 0.0f, 0.0f, 0.0f, -1.0f, 0.0f, 0.0f,
         0.5f, 0.1f, 0.0f, 0.0f, 0.0f, -1.0f, 0.0f, 1.0f,
         0.5f, 0.1f, 0.0f, 0.0f, 0.0f, -1.0f, 0.0f, 1.0f,
        -0.5f, 0.0f, 0.0f, 0.0f, 0.0f, -1.0f, 1.0f, 0.0f,
         0.5f, 0.0f, 0.0f, 0.0f, 0.0f, -1.0f, 1.0f, 1.0f,

        //Top face
        -0.5f, 0.1f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 
        -0.5f, 0.1f, 0.2f, 0.0f, 1.0f, 0.0f, 1.0f, 0.0f,
         0.5f, 0.1f, 0.2f, 0.0f, 1.0f, 0.0f, 1.0f, 1.0f,
         0.5f, 0.1f, 0.2f, 0.0f, 1.0f, 0.0f, 1.0f, 1.0f,
         0.5f, 0.1f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 1.0f,
        -0.5f, 0.1f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f,

        // Bottom face
        -0.5f, 0.0f, 0.0f, 0.0f, -1.0f, 0.0f, 0.0f, 0.0f,
        -0.5f, 0.0f, 0.2f, 0.0f, -1.0f, 0.0f, 1.0f, 0.0f,
         0.5f, 0.0f, 0.2f, 0.0f, -1.0f, 0.0f, 1.0f, 1.0f,
         0.5f, 0.0f, 0.2f, 0.0f, -1.0f, 0.0f, 1.0f, 1.0f,
         0.5f, 0.0f, 0.0f, 0.0f, -1.0f, 0.0f, 0.0f, 1.0f,
        -0.5f, 0.0f, 0.0f, 0.0f, -1.0f, 0.0f, 0.0f, 0.0f,

        // left face
         -0.5,  0.0, 0.2f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f,
        -0.5f, 0.1f, 0.2f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f,
        -0.5f, 0.1f, 0.0f, -1.0f, 0.0f, 0.0f, 0.0f, 1.0f,
        -0.5f, 0.1f, 0.0f, -1.0f, 0.0f, 0.0f, 0.0f, 1.0f,
        -0.5f, 0.0f, 0.0f, -1.0f, 0.0f, 0.0f, 0.0f, 0.0f,
        -0.5f, 0.0f, 0.2f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f,

        // Right face
        0.5f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.9f,
        0.5f, 0.1f, 0.0f, 1.0f, 0.0f, 0.0f, 1.0f, 0.9f,
        0.5f, 0.1f, 0.2f, 1.0f, 0.0f, 0.0f, 1.0f, 1.0f,
        0.5f, 0.1f, 0.2f, 1.0f, 0.0f, 0.0f, 1.0f, 1.0f,
        0.5f, 0.0f, 0.2f, 1.0f, 0.0f, 0.0f, 0.0f, 1.0f,
        0.5f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.9f
    };
    
    // Define array of point light positions
    pointLightPositions = { 
        glm::vec3(-500.0f, 4.5f, -1.0f),
        glm::vec3(5.0f,  4.5f, -1.0f),
        glm::vec3(0.0f,  4.5f, -3.0f),
        glm::vec3(-15.0f,  3.5f, 6.5f),
    };

    // Phase 2 -> Load object textures from files
     // Load textures!
    if (!UCreateTexture("tabletop.jpg", textures.at(0)))
    {
        std::cout << "Unable to load table texture" << std::endl;
    }
        
    if (!UCreateTexture("blue.png", textures.at(1)))
    {
        std::cout << "Unable to load top/bottom cylinder texture" << std::endl;
    }

   
    if (!UCreateTexture("middle.png", textures.at(2)))
    {
        std::cout << "Unable to load middle cylinder texture" << std::endl;
    }

    if (!UCreateTexture("silver.png", textures.at(3)))
    {
        std::cout << "Unable to load egg texture" << std::endl;
    }

    if (!UCreateTexture("battery.png", textures.at(4)))
    {
        std::cout << "Unable to load battery texture" << std::endl;
    }

    if (!UCreateTexture("mug.png", textures.at(5)))
    {
        std::cout << "Unable to load mug texture" << std::endl;
    }



    // Phase 3 -> Create VAO's for various objects

    // Create battery object from Cube class
    batteryObject = Cube(batteryVertices, textures.at(4));
    dirLightCube = Cube(cubeVertices);
    for (auto i = 0; i < NUM_POINT_LIGHTS; ++i)
    {
        pointLightCubes.at(i) = Cube(cubeVertices);
    }

    // Bottom/Top Cylinder of E-Tank Model Mesh
    // Generate and activate VAOs, VBOs
    glGenVertexArrays(1, &meshes.at(1).vao);
    glGenBuffers(1, &meshes.at(1).vbo);
    glBindVertexArray(meshes.at(1).vao);
    glBindBuffer(GL_ARRAY_BUFFER, meshes.at(1).vbo);    


    // Instantiate sphere and cylinder objects (low polygon mode)
    if (LOW_POLYGON_COUNT_MODE)
    {
        sphere = Sphere(1.0f, 15, 12);
        bottomCylinder  = std::make_unique<Cylinder>(2.0f, 735, 0.5f);
        topCylinder     = std::make_unique<Cylinder>(2.0f, 735, 0.5f);
        middleCylinder  = std::make_unique<Cylinder>(1.75f,735, 2.5f);
        coffeeCup       = std::make_unique<Cylinder>(1.75f, 735, 3.0f);
        coffeeCupHandle = std::make_unique<Cylinder>(0.75f, 735, 0.5f);
    }
    else // (high polygon mode)
    {
        sphere = Sphere();
        bottomCylinder  = std::make_unique<Cylinder>(2.0f,  1800, 0.5f);
        topCylinder     = std::make_unique<Cylinder>(2.0f,  1800, 0.5f);
        middleCylinder  = std::make_unique<Cylinder>(1.75f, 1800, 2.5f);
        coffeeCup       = std::make_unique<Cylinder>(1.75f, 1800, 3.0f);
        coffeeCupHandle = std::make_unique<Cylinder>(0.75f, 1800, 0.5f);
    }

    // Pinball Mesh
    // copy interleaved vertex data (V/N/T) to VBO
    sphere.generateMesh();

    // Instantiate plane object
    table = Plane(planeVertexArray, textures.at(0));

}

// Destroy meshes
void UDestroyMesh(std::array<GLMesh, NUMBER_OF_MESHES> meshes)
{
    for (auto const &mesh : meshes) {
        glDeleteVertexArrays(1, &mesh.vao);
        glDeleteBuffers(1, &mesh.vbo);
    }
}

// Handle mouse cursor movement
void UMousePositionCallback(GLFWwindow* window, double xposIn, double yposIn) {
    // Convert doubles to floats
    float xpos = static_cast<float>(xposIn);
    float ypos = static_cast<float>(yposIn);

    // IF this is the first mouse input, don't change view
    if (gFirstMouse) {
        gLastX = xpos;
        gLastY = ypos;
        gFirstMouse = false;
    }

    // Calculate x and y offset
    float xoffset = xpos - gLastX;
    float yoffset = gLastY - ypos;

    // Update last positions
    gLastX = xpos;
    gLastY = ypos;

    // Call camera class to process mouse movements
    gCamera.ProcessMouseMovement(xoffset, yoffset);
}

// Handle mouse scroll wheel input
void UScrollCallback(GLFWwindow* window, double xoffsetIn, double yoffsetIn) {
    // Convert y offset double to float (x offset not needed)
    float yoffset = static_cast<float>(yoffsetIn);

    // Call camera class function to change the camera movement speed
    gCamera.UpdateMovementSpeed(yoffset);
}

// Handle mouse button input
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods) {
    // If middle mouse button was pressed...
    if (button == GLFW_MOUSE_BUTTON_MIDDLE && action == GLFW_PRESS) {
        // Reset camera speed to default value
        gCamera.ResetMovementSpeed();
 
    }
}

// Set default texture parameters
void USetDefaultTextureParameters()
{
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
}

// Generate and load texture
bool UCreateTexture(const char* filename, GLuint& textureId)
{
    int width, height, channels;
    unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
    if (image)
    {
        flipImageVertically(image, width, height, channels);

        glGenTextures(1, &textureId);
        glBindTexture(GL_TEXTURE_2D, textureId);

        // set the texture wrapping parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        // set texture filtering parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        // Load image
        if (channels == 3)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        else if (channels == 4)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        else
        {
            std::cout << "Not implemented to handle image with " << channels << " channels" << std::endl;
            return false;
        }

        // Generate mipmaps, release raw image data, and unbind the texture
        glGenerateMipmap(GL_TEXTURE_2D);
        stbi_image_free(image);

        glBindTexture(GL_TEXTURE_2D, 0);

        return true; // Indicate success
    }

    return false; // Indicate failure

}

// Flips image vertically.
void flipImageVertically(unsigned char* image, int width, int height, int channels)
{
    for (int j = 0; j < height / 2; ++j)
    {
        int index1 = j * width * channels;
        int index2 = (height - 1 - j) * width * channels;

        for (int i = width * channels; i > 0; --i)
        {
            unsigned char tmp = image[index1];
            image[index1] = image[index2];
            image[index2] = tmp;
            ++index1;
            ++index2;
        }
    }
}

// Set basic lighting & material properties.
void setMaterialProperties(Shader* shader, Materials material)
{
    if (material == Materials::METALLIC)
    {
        shader->setVec3("light.ambient", glm::vec3(0.19225));
        shader->setVec3("material.specluar", glm::vec3(1.0));
        shader->setFloat("material.shininess", 2.0 );
    }
    else { // set generic settings
        shader->setVec3("light.ambient", glm::vec3(0.2f));
        shader->setVec3("material.specular", glm::vec3(0.5f));
        shader->setFloat("material.shininess", 64.0f);
    }
}

// Handle key presses for toggles 
void UKeyCallback(GLFWwindow *window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_P && action == GLFW_PRESS)
    {
        orthographicView = !orthographicView;   
    }
}

// Function to set material, lighting, and texture property
// unforms for the GPU.
void USetupUniforms()
{

    // Setup material, lighting, and texture properties

    objectShader->setVec3("viewPos", gCamera.Position);
    objectShader->setVec3("material.ambient", 1.0f, 0.5f, 0.31f);
    objectShader->setInt("material.diffuse", 0);
    objectShader->setVec3("material.specular", 0.5f, 0.5f, 0.5f);
    objectShader->setFloat("material.shininess", 64.0f);


    // directional light
    objectShader->setVec3("dirLight.direction", lightDir);
    objectShader->setVec3("dirLight.ambient", 0.3f, 0.3f, 0.3f); 
    objectShader->setVec3("dirLight.diffuse", 0.8f, 0.8f, 0.8f);
    objectShader->setVec3("dirLight.specular", 1.0f, 1.0f, 1.0f);

    // point light 1
    objectShader->setVec3("pointLights[0].position", pointLightPositions.at(0));
    objectShader->setVec3("pointLights[0].ambient", 0.05f, 0.05f, 0.05f);
    objectShader->setVec3("pointLights[0].diffuse", 0.8f, 0.8f, 0.8f);
    objectShader->setVec3("pointLights[0].specular", 1.0f, 1.0f, 1.0f);
    objectShader->setFloat("pointLights[0].constant", 1.0f);
    objectShader->setFloat("pointLights[0].linear", 0.07f);
    objectShader->setFloat("pointLights[0].quadratic", 0.017f);
    
    // point light 2
    objectShader->setVec3("pointLights[1].position", pointLightPositions.at(1));
    objectShader->setVec3("pointLights[1].ambient", 0.05f, 0.05f, 0.05f);
    objectShader->setVec3("pointLights[1].diffuse", 0.8f, 0.8f, 0.8f);
    objectShader->setVec3("pointLights[1].specular", 1.0f, 1.0f, 1.0f);
    objectShader->setFloat("pointLights[1].constant", 1.0f);
    objectShader->setFloat("pointLights[1].linear", 0.07f);
    objectShader->setFloat("pointLights[1].quadratic", 0.017f);

    // point light 3
    objectShader->setVec3("pointLights[2].position", pointLightPositions.at(2));
    objectShader->setVec3("pointLights[2].ambient", 0.05f, 0.05f, 0.05f);
    objectShader->setVec3("pointLights[2].diffuse", 0.8f, 0.8f, 0.8f);
    objectShader->setVec3("pointLights[2].specular", 1.0f, 1.0f, 1.0f);
    objectShader->setFloat("pointLights[2].constant", 1.0f);
    objectShader->setFloat("pointLights[2].linear", 0.07f);
    objectShader->setFloat("pointLights[2].quadratic", 0.017f);
    
    // point light 4
    objectShader->setVec3("pointLights[3].position", pointLightPositions.at(3));
    objectShader->setVec3("pointLights[3].ambient", 0.05f, 0.05f, 0.05f);
    objectShader->setVec3("pointLights[3].diffuse", 0.8f, 0.8f, 0.8f);
    objectShader->setVec3("pointLights[3].specular", 1.0f, 1.0f, 1.0f);
    objectShader->setFloat("pointLights[3].constant", 1.0f);
    objectShader->setFloat("pointLights[3].linear", 0.07f);
    objectShader->setFloat("pointLights[3].quadratic", 0.017f);
}