/* Cube.h 
 *
 * Class to contain mesh and texture for 
 * an OpenGl cube object.
 * 
 * Charles Haines 
 * Southern New Hampshire University 2022
 * CS330
 */

#include "mesh.h"
#include "shader.h"
#include <vector>
#include <array>
#include <iostream>

constexpr size_t VERTEX_ARRAY_SIZE      { 6 * 6 * 8 }; // verts per face * # of faces * floats per vertex
constexpr size_t FLOATS_PER_VERTEX      { 3 };
constexpr size_t FLOATS_PER_NORMAL      { 3 };
constexpr size_t FLOATS_PER_TEX_COORD   { 2 };

constexpr size_t stride { (FLOATS_PER_VERTEX + FLOATS_PER_NORMAL + FLOATS_PER_TEX_COORD) * sizeof(GLfloat) };

class Cube
{
 public:

    // Default constructor
    Cube();
    // Construct cube object from a std::vector of vertices.
    // 
    Cube(std::array<GLfloat, 6 * 6 * 8> vertexArray, GLuint texture = 0);
    // Construct cube object from float array.
    //Cube(float vertices[]);
    void draw();

 private:
    
    GLMesh mesh;
    GLuint texture;

};